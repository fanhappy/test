//
//  ViewController.m
//  GitDemo
//
//  Created by tarena on 16/4/11.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ViewController.h"
#import "TestClass.h"
@interface ViewController ()
@property(nonatomic)int sum;

@property(nonatomic,strong)TestClass * testClass;
@end

@implementation ViewController
-(void)sayHello
{
    NSLog(@"hello");
}
- (void)viewDidLoad {
    [super viewDidLoad];
    int a = 5;
    int b = 10;
    self.sum = a + b ;
    NSLog(@"%d",self.sum);
    [self sayHello];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
